# fast rub

This Python library is for SPlus platform bots and is currently being updated.

## fast rub

- 1 fast
- 2 simple syntax
- 3 Small size of the library

## install :

```bash
pip install https://ParsSource.ir/PySPlus/PySPlus-0.2.tar.gz
```